﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamworkProjects
{
    public class TeamworkProjects
    {
        public static void Main()
        {
            var teams = new List<Team>();

            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                var teamCreate = Console.ReadLine().Split('-');
                var creatorName = teamCreate[0];
                var teamName = teamCreate[1];
                var team = new Team(teamName, creatorName);
                team.Members.Add(creatorName);
                if (teams.Select(x=>x.Name).Contains(teamName))
                {
                    Console.WriteLine($"Team {teamName} was already created!");
                    continue;
                }
                if (teams.Select(x => x.CreatorName).Contains(creatorName))
                {
                    Console.WriteLine($"{creatorName} cannot create another team!");
                    continue;
                }
                Console.WriteLine($"Team {team.Name} has been created by {team.CreatorName}!");
                teams.Add(team);
            }

            var input = Console.ReadLine();

            while (input != "end of assignment")
            {
                var memberJoin = input.Split(new char[] { '-', '>' }, StringSplitOptions.RemoveEmptyEntries);
                var member = memberJoin[0];
                var team = memberJoin[1];
                if (teams.Select(x=>x.Name).Contains(team))
                {
                    
                    if (teams.Select(x => x.Members).Any(b => b.Contains(member)) || teams.Select(x => x.CreatorName).Any(b => b.Contains(member)))
                    {
                        Console.WriteLine($"Member {member} cannot join team {team}!");
                    }
                    else
                    {
                        teams.First(d => d.Name == team).Members.Add(member);
                    }
                }
                else
                {
                    Console.WriteLine($"Team {team} does not exist!");
                }

                input = Console.ReadLine();
            }
            var teamWithMembers = teams.Where(x => x.Members.Count > 1).ToList();
            var teamWithoutMembers = teams.Where(x => x.Members.Count == 1).ToList();

            foreach (var team in teamWithMembers.OrderByDescending(x=>x.Members.Count()).ThenBy(x=>x.Members))
            {
                Console.WriteLine($"{team.Name}");
                foreach (var member in team.Members)
                {
                    if (member == team.Members.First())
                    {
                        Console.WriteLine("{0} {1}", new string('-', 1), member);
                    }
                    else
                    {
                        Console.WriteLine("{0} {1}", new string('-', 2), member);
                    }
                }
            }
            Console.WriteLine("Teams to disband:");
            foreach (var team in teamWithoutMembers)
            {
                Console.WriteLine($"{team.Name}");
            }

        }
    }
}
